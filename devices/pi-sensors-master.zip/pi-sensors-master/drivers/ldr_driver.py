import RPi.GPIO as GPIO
import time
from .settings import LDR_PIN

GPIO.setmode(GPIO.BCM)

#define the pin that goes to the circuit
pin_to_circuit = LDR_PIN

def rc_time (pin_to_circuit):
    count = 0
  
    #Output on the pin for 
    GPIO.setup(pin_to_circuit, GPIO.OUT)
    GPIO.output(pin_to_circuit, GPIO.LOW)
    time.sleep(0.1)

    #Change the pin back to input
    GPIO.setup(pin_to_circuit, GPIO.IN)
  
    #Count until the pin goes high
    while (GPIO.input(pin_to_circuit) == GPIO.LOW):
        count += 1

    return count


def ldr_samples(count=10):
    samples=[]
    for i in range(count):
        samples.append(rc_time(pin_to_circuit))
    average = sum(samples) / len(samples)

    return average


def get_ldr_value():
    return ldr_samples(20)

def run(callback):
    try:
        # Main loop
        while True:
            # print rc_time(pin_to_circuit)
            ldr_value = get_ldr_value()
            callback({'type': 'LDR', 'payload': ldr_value})
            time.sleep(5)
    except KeyboardInterrupt:
        pass
    finally:
        GPIO.cleanup()

if __name__ == '__main__':
    #Catch when script is interrupted, cleanup correctly
    try:
        # Main loop
        while True:
            # print rc_time(pin_to_circuit)
            print(get_ldr_value())
            time.sleep(.5)
    except KeyboardInterrupt:
        pass
    finally:
        GPIO.cleanup()
