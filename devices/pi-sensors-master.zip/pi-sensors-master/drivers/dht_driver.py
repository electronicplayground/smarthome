from time import sleep

from .dht import get_dht_values

def run(callback):
    while True:
        h, t = get_dht_values()
        if t is not None and h is not None:
            callback({
                'type': 'DHT',
                # t-2 as DHT22 seems to report +2 degrees
                'payload': {'temperature': round(t-2, 2), 'humidity': round(h, 2)},
            })
        sleep(2)
