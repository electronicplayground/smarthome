import time
from .settings import PIR_PIN

import RPi.GPIO as GPIO

GPIO.setmode(GPIO.BCM)
GPIO.setup(PIR_PIN, GPIO.IN)

def run(callback=None):
    try:
        time.sleep(2)
        while True:
            if GPIO.input(PIR_PIN):
                callback({'type': 'PIR', 'payload': True})
                time.sleep(5)
                callback({'type': 'PIR', 'payload': False})
            time.sleep(0.1)
    except:
        print('exception PIR')
        GPIO.cleanup()


