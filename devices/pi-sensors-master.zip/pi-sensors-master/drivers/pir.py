import time
from gpiozero import MotionSensor
from settings import PIR_PIN

pir=MotionSensor(PIR_PIN)

def run():
    print('pir')
    while True:
        print('pir')
        pir.wait_for_motion()
        print("you moved")
        pir.wait_for_no_motion()
        print('no motion')


if __name__ == '__main__':
    run()
