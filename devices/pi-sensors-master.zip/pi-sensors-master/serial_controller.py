import os
import time
import datetime
import json

from multiprocessing import Pool

import mqtt_client
import serial
import argparse_utils
import serial_utils
import settings


ports = serial_utils.list_ports()
print(ports)


args = argparse_utils.check_args()



def sensor_data_event(data):
    if not isinstance(data, str):
        data = json.dumps(data)
    mqtt_client.publish('/mother/sensors', data)


def serial_sensor_proc():
    with serial.Serial(args.port) as ser:
        ser.baudrate = settings.SERIAL_BAUDRATE

        while True:
            #  reads a line from serial and returns byte array
            line = ser.readline()
            if not line:
                continue
            line = line.decode('utf-8')
            # print(line)
            sensor_data_event(line)


def mqtt_message(client, userdata, msg):
    print(msg.payload)

def mqtt_proc():
    mqtt_client.run(mqtt_message)


processes = {
    'serial_sensor_proc': serial_sensor_proc,
    'mqtt_proc': mqtt_proc,
}


def run_process(process):
    while True:
        try:
            with open('logs.txt', 'a+') as logs:
                message = '{}, {}, Starting {}\n'.format(datetime.datetime.utcnow(), 'LOG', process.__name__)
                logs.write(message)
            process()
        except Exception as e:
            with open('logs.txt', 'a+') as logs:
                message = '{}, {}, {} {}\n'.format(datetime.datetime.utcnow(), 'ERROR', process.__name__, str(e))
                print(message)
                logs.write(message)
            time.sleep(4)


def get_processes():
    return list(processes.values())


if __name__ == '__main__':
    with Pool(processes=len(processes)) as pool:
        pool.map(run_process, get_processes())
