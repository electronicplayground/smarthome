import subprocess


def list_ports():
    cmd = 'python -m serial.tools.list_ports'
    result = subprocess.check_output(cmd, shell=True)
    return result


if __name__ == '__main__':
    print('Serial ports available')
    print(list_ports())
