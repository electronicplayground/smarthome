# pi-sensors
Scripts to run sensors connected to raspberry pi. 

Take data from DHT22, PIR and an LDR and publish to local MQTT broker (mosquitto).
Node RED interface.


# Setup

```bash
git clone https://github.com/electronicplayground/pi-sensors.git
```

## Install mosquitto mqtt broker
```bash
sudo apt install -y mosquitto mosquitto-clients
```

## RPi.GPIO
```bash
pip3 install RPi.GPIO
```

## DHT library
[Adafruit_Python_DHT](https://github.com/adafruit/Adafruit_Python_DHT)

## paho-mqtt
```bash
pip3 install paho-mqtt
```

# Run
$ python3 sensors.py
