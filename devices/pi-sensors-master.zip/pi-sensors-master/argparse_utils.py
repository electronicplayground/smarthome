import argparse


def check_args():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "port",
        help="enter the port number. ex: COM3 or /dev/ttyUSB1")

    args = parser.parse_args()
    return args
