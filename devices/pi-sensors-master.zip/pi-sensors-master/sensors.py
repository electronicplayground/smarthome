import os
import time
import datetime
import json

from multiprocessing import Pool

from drivers import (
    pir_driver,
    dht_driver,
#    ldr_driver,
)

import mqtt_client


def sensor_data_event(data):
    mqtt_client.publish('/mother/sensors', json.dumps(data))


def pir_proc():
    pir_driver.run(sensor_data_event)


def dht_proc():
    dht_driver.run(sensor_data_event)


def ldr_proc():
    ldr_driver.run(sensor_data_event)


def mqtt_message(client, userdata, msg):
    print(msg.payload)


def mqtt_proc():
    mqtt_client.run(mqtt_message)


processes = {
    'pir_proc': pir_proc,
    'dht_proc': dht_proc,
    # 'ldr_proc': ldr_proc,
    'mqtt_proc': mqtt_proc,
}


def run_process(process):
    while True:
        try:
            with open('logs.txt', 'a+') as logs:
                message = '{}, {}, Starting {}\n'.format(datetime.datetime.utcnow(), 'LOG', process.__name__)
                logs.write(message)
            process()
        except Exception as e:
            with open('logs.txt', 'a+') as logs:
                message = '{}, {}, {} {}\n'.format(datetime.datetime.utcnow(), 'ERROR', process.__name__, str(e))
                print(message)
                logs.write(message)
            time.sleep(4)


def get_processes():
    return list(processes.values())


if __name__ == '__main__':
    #processes['process_monitor'] = process_monitor
    with Pool(processes=len(processes)) as pool:
        pool.map(run_process, get_processes())
