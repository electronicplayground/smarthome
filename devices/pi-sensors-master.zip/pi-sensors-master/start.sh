#!/bin/bash
python3 serial_controller.py /dev/ttyACM0 > /dev/null 2>&1 &
