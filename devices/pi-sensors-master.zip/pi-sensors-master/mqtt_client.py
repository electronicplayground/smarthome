import time
import paho.mqtt.client as mqtt

topics = ['/mother/sensors/temp/in']

mqtt_client = mqtt.Client()
def on_connect(client, userdata, flags, rc):
    print("Connected with result code "+str(rc))
    for topic in topics:
        client.subscribe(topic)

def on_message(client, userdata, msg):
    print(msg.payload)

mqtt_client.on_connect = on_connect
mqtt_client.on_message = on_message

mqtt_client.connect('192.168.0.31', 1883, 60)

def publish(topic, msg_str):
    mqtt_client.publish(topic, msg_str)

def run(callback):
    mqtt_client.on_message = callback
    while True:
        mqtt_client.loop()
        time.sleep(0.2)


